#!/usr/bin/env python3
"""
ORI Signal Checker - Comprehensive Origin of Replication Analysis
Includes k-mer enrichment, clump finding, and GC skew analysis
"""

import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict, Counter
import argparse
from pathlib import Path


def read_fasta(filepath):
    """Read a FASTA file and return the sequence as a string."""
    sequence = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line.startswith('>'):
                sequence.append(line.upper())
    return ''.join(sequence)


def reverse_complement(seq):
    """Return the reverse complement of a DNA sequence."""
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G', 'N': 'N'}
    return ''.join(complement.get(base, 'N') for base in reversed(seq))


def count_kmers_in_window(sequence, start, end, k):
    """Count all k-mers (including reverse complements) in a window."""
    kmer_counts = Counter()
    
    for i in range(start, min(end - k + 1, len(sequence) - k + 1)):
        kmer = sequence[i:i+k]
        if 'N' not in kmer:  # Skip k-mers with ambiguous bases
            rev_comp = reverse_complement(kmer)
            # Use canonical k-mer (lexicographically smaller)
            canonical = min(kmer, rev_comp)
            kmer_counts[canonical] += 1
    
    return kmer_counts


def kmer_enrichment_analysis(sequence, k=8, window_size=5000, step=500):
    """
    Perform k-mer enrichment analysis across the genome.
    Returns positions, top k-mers, and their counts per window.
    """
    print(f"\n{'='*60}")
    print(f"K-MER ENRICHMENT ANALYSIS")
    print(f"{'='*60}")
    print(f"Parameters: k={k}, window_size={window_size}, step={step}")
    
    positions = []
    all_kmer_counts = []
    
    # Sliding window analysis
    for start in range(0, len(sequence) - window_size + 1, step):
        end = start + window_size
        window_center = start + window_size // 2
        positions.append(window_center)
        
        kmer_counts = count_kmers_in_window(sequence, start, end, k)
        all_kmer_counts.append(kmer_counts)
    
    # Find globally most frequent k-mers
    global_kmer_counts = Counter()
    for kmer_counts in all_kmer_counts:
        global_kmer_counts.update(kmer_counts)
    
    top_kmers = [kmer for kmer, _ in global_kmer_counts.most_common(10)]
    
    print(f"\nTop 10 most frequent {k}-mers globally:")
    for i, (kmer, count) in enumerate(global_kmer_counts.most_common(10), 1):
        print(f"{i:2d}. {kmer}: {count:6d} occurrences")
    
    # Create matrix of counts for top k-mers across windows
    enrichment_matrix = np.zeros((len(top_kmers), len(positions)))
    for i, kmer in enumerate(top_kmers):
        for j, counts in enumerate(all_kmer_counts):
            enrichment_matrix[i, j] = counts.get(kmer, 0)
    
    return positions, top_kmers, enrichment_matrix, all_kmer_counts


def find_clumps(sequence, L=1000, k=8, t=3):
    """
    Find (L, k, t)-clumps: k-mers appearing at least t times within L-length windows.
    Returns dictionary of clump k-mers with their positions.
    """
    print(f"\n{'='*60}")
    print(f"CLUMP FINDING ANALYSIS")
    print(f"{'='*60}")
    print(f"Parameters: L={L}, k={k}, t={t}")
    
    clump_kmers = set()
    kmer_positions = defaultdict(list)
    
    # First pass: record all k-mer positions
    for i in range(len(sequence) - k + 1):
        kmer = sequence[i:i+k]
        if 'N' not in kmer:
            rev_comp = reverse_complement(kmer)
            canonical = min(kmer, rev_comp)
            kmer_positions[canonical].append(i)
    
    # Second pass: check for clumps
    for kmer, positions in kmer_positions.items():
        # Check each position to see if there are t-1 more occurrences within L
        for i, pos in enumerate(positions):
            count = 1
            for j in range(i + 1, len(positions)):
                if positions[j] - pos < L:
                    count += 1
                    if count >= t:
                        clump_kmers.add(kmer)
                        break
                else:
                    break
            if kmer in clump_kmers:
                break
    
    print(f"\nFound {len(clump_kmers)} k-mers forming ({L}, {k}, {t})-clumps")
    
    # Get clump regions
    clump_regions = []
    for kmer in clump_kmers:
        positions = kmer_positions[kmer]
        # Find dense regions
        for i, pos in enumerate(positions):
            window_positions = [p for p in positions if pos <= p < pos + L]
            if len(window_positions) >= t:
                clump_regions.append({
                    'kmer': kmer,
                    'start': pos,
                    'end': pos + L,
                    'count': len(window_positions)
                })
    
    # Sort by start position
    clump_regions.sort(key=lambda x: x['start'])
    
    print(f"\nTop 10 clump regions:")
    for i, region in enumerate(sorted(clump_regions, key=lambda x: x['count'], reverse=True)[:10], 1):
        print(f"{i:2d}. {region['kmer']} at position {region['start']:8d}-{region['end']:8d} "
              f"(count: {region['count']})")
    
    return clump_kmers, kmer_positions, clump_regions


def calculate_gc_skew(sequence, window_size=5000, step=500):
    """
    Calculate GC skew across the genome using sliding windows.
    GC skew = (G - C) / (G + C)
    """
    print(f"\n{'='*60}")
    print(f"GC SKEW ANALYSIS")
    print(f"{'='*60}")
    print(f"Parameters: window_size={window_size}, step={step}")
    
    positions = []
    gc_skew_values = []
    cumulative_skew = [0]
    
    for start in range(0, len(sequence) - window_size + 1, step):
        end = start + window_size
        window = sequence[start:end]
        
        g_count = window.count('G')
        c_count = window.count('C')
        
        if g_count + c_count > 0:
            skew = (g_count - c_count) / (g_count + c_count)
        else:
            skew = 0
        
        window_center = start + window_size // 2
        positions.append(window_center)
        gc_skew_values.append(skew)
    
    # Calculate cumulative skew
    for i in range(len(sequence)):
        base = sequence[i]
        if base == 'G':
            cumulative_skew.append(cumulative_skew[-1] + 1)
        elif base == 'C':
            cumulative_skew.append(cumulative_skew[-1] - 1)
        else:
            cumulative_skew.append(cumulative_skew[-1])
    
    # Find minimum cumulative skew (potential ORI)
    min_skew = min(cumulative_skew)
    min_positions = [i for i, skew in enumerate(cumulative_skew) if skew == min_skew]
    
    print(f"\nGC Skew Statistics:")
    print(f"  Mean GC skew: {np.mean(gc_skew_values):.4f}")
    print(f"  Min GC skew:  {np.min(gc_skew_values):.4f}")
    print(f"  Max GC skew:  {np.max(gc_skew_values):.4f}")
    print(f"\nCumulative GC Skew:")
    print(f"  Minimum value: {min_skew}")
    print(f"  Minimum positions: {min_positions[:5]}{'...' if len(min_positions) > 5 else ''}")
    
    return positions, gc_skew_values, cumulative_skew, min_positions


def find_ori_candidates(sequence, k=8, window_size=5000, step=500, 
                        clump_kmers=None, min_skew_positions=None):
    """
    Identify ORI candidates by combining k-mer enrichment and GC skew analysis.
    """
    print(f"\n{'='*60}")
    print(f"ORI CANDIDATE IDENTIFICATION")
    print(f"{'='*60}")
    
    ori_candidates = []
    
    # Regions around minimum cumulative skew
    if min_skew_positions:
        for pos in min_skew_positions[:3]:  # Top 3 minimum positions
            start = max(0, pos - window_size // 2)
            end = min(len(sequence), pos + window_size // 2)
            
            # Count clump k-mers in this region
            region_seq = sequence[start:end]
            clump_count = 0
            if clump_kmers:
                for i in range(len(region_seq) - k + 1):
                    kmer = region_seq[i:i+k]
                    rev_comp = reverse_complement(kmer)
                    canonical = min(kmer, rev_comp)
                    if canonical in clump_kmers:
                        clump_count += 1
            
            ori_candidates.append({
                'position': pos,
                'start': start,
                'end': end,
                'clump_count': clump_count,
                'score': clump_count  # Simple scoring
            })
    
    # Sort by score
    ori_candidates.sort(key=lambda x: x['score'], reverse=True)
    
    print(f"\nTop ORI candidates (based on minimum cumulative GC skew):")
    for i, candidate in enumerate(ori_candidates[:5], 1):
        print(f"{i}. Position {candidate['position']:8d} "
              f"(region: {candidate['start']:8d}-{candidate['end']:8d})")
        print(f"   Clump k-mers in region: {candidate['clump_count']}")
        print(f"   Score: {candidate['score']:.2f}")
    
    return ori_candidates


def plot_results(positions, enrichment_matrix, top_kmers, gc_skew_positions, 
                 gc_skew_values, cumulative_skew, clump_regions, 
                 ori_candidates, output_prefix='ori_analysis'):
    """
    Create comprehensive visualization of all analyses.
    """
    print(f"\n{'='*60}")
    print(f"GENERATING PLOTS")
    print(f"{'='*60}")
    
    fig = plt.figure(figsize=(16, 12))
    gs = fig.add_gridspec(4, 1, hspace=0.3)
    
    # Plot 1: K-mer enrichment heatmap
    ax1 = fig.add_subplot(gs[0])
    im = ax1.imshow(enrichment_matrix, aspect='auto', cmap='YlOrRd', 
                    interpolation='nearest')
    ax1.set_xlabel('Genomic Position')
    ax1.set_ylabel('K-mer')
    ax1.set_title('K-mer Enrichment Across Genome', fontsize=14, fontweight='bold')
    
    # Set x-axis to show actual positions
    x_ticks = np.linspace(0, len(positions)-1, 10, dtype=int)
    ax1.set_xticks(x_ticks)
    ax1.set_xticklabels([f'{positions[i]:,}' for i in x_ticks], rotation=45)
    
    # Set y-axis to show k-mer sequences
    ax1.set_yticks(range(len(top_kmers)))
    ax1.set_yticklabels(top_kmers, fontsize=8)
    
    plt.colorbar(im, ax=ax1, label='Count')
    
    # Plot 2: Top k-mers line plot
    ax2 = fig.add_subplot(gs[1])
    for i, kmer in enumerate(top_kmers[:5]):  # Plot top 5
        ax2.plot(positions, enrichment_matrix[i, :], label=kmer, linewidth=1.5)
    ax2.set_xlabel('Genomic Position')
    ax2.set_ylabel('K-mer Count')
    ax2.set_title('Top 5 K-mer Frequencies', fontsize=14, fontweight='bold')
    ax2.legend(loc='upper right', fontsize=8)
    ax2.grid(True, alpha=0.3)
    
    # Plot 3: GC Skew
    ax3 = fig.add_subplot(gs[2])
    ax3.plot(gc_skew_positions, gc_skew_values, 'b-', linewidth=1.5)
    ax3.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
    ax3.set_xlabel('Genomic Position')
    ax3.set_ylabel('GC Skew')
    ax3.set_title('GC Skew Across Genome', fontsize=14, fontweight='bold')
    ax3.grid(True, alpha=0.3)
    
    # Highlight ORI candidates
    if ori_candidates:
        for candidate in ori_candidates[:3]:
            ax3.axvline(x=candidate['position'], color='red', 
                       linestyle='--', alpha=0.7, linewidth=2)
    
    # Plot 4: Cumulative GC Skew
    ax4 = fig.add_subplot(gs[3])
    ax4.plot(cumulative_skew, 'g-', linewidth=1)
    ax4.set_xlabel('Genomic Position')
    ax4.set_ylabel('Cumulative GC Skew')
    ax4.set_title('Cumulative GC Skew (Minimum indicates potential ORI)', 
                  fontsize=14, fontweight='bold')
    ax4.grid(True, alpha=0.3)
    
    # Highlight minimum positions
    min_skew = min(cumulative_skew)
    min_positions = [i for i, skew in enumerate(cumulative_skew) if skew == min_skew]
    for pos in min_positions[:3]:
        ax4.axvline(x=pos, color='red', linestyle='--', alpha=0.7, linewidth=2)
        ax4.plot(pos, min_skew, 'ro', markersize=10)
    
    plt.tight_layout()
    
    output_file = f'{output_prefix}_comprehensive.png'
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"\nSaved comprehensive plot: {output_file}")
    
    # Create separate detailed plots
    
    # Detailed clump regions plot
    if clump_regions:
        fig2, ax = plt.subplots(figsize=(14, 6))
        
        # Plot clump density
        clump_density = np.zeros(len(cumulative_skew))
        for region in clump_regions:
            clump_density[region['start']:region['end']] += 1
        
        ax.fill_between(range(len(clump_density)), clump_density, 
                        alpha=0.6, color='orange', label='Clump density')
        ax.set_xlabel('Genomic Position')
        ax.set_ylabel('Clump Density')
        ax.set_title('Clump Region Density Across Genome', 
                    fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        output_file2 = f'{output_prefix}_clump_density.png'
        plt.savefig(output_file2, dpi=300, bbox_inches='tight')
        print(f"Saved clump density plot: {output_file2}")
    
    plt.close('all')


def main():
    parser = argparse.ArgumentParser(
        description='ORI Signal Checker - Analyze genomic sequences for origin of replication signals',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  python ori_analyzer.py genomic.fa
  python ori_analyzer.py genomic.fa -k 9 -w 10000
  python ori_analyzer.py genomic.fa -o my_results
        '''
    )
    
    parser.add_argument('fasta_file', type=str, 
                       help='Path to genomic FASTA file (e.g., genomic.fa)')
    parser.add_argument('-k', '--kmer-size', type=int, default=8,
                       help='K-mer size (default: 8)')
    parser.add_argument('-w', '--window-size', type=int, default=5000,
                       help='Window size for k-mer enrichment and GC skew (default: 5000)')
    parser.add_argument('-s', '--step', type=int, default=500,
                       help='Step size for sliding window (default: 500)')
    parser.add_argument('-L', '--clump-length', type=int, default=1000,
                       help='Window length L for clump finding (default: 1000)')
    parser.add_argument('-t', '--clump-threshold', type=int, default=3,
                       help='Minimum occurrences t for clump finding (default: 3)')
    parser.add_argument('-o', '--output-prefix', type=str, default='ori_analysis',
                       help='Output prefix for plots and results (default: ori_analysis)')
    
    args = parser.parse_args()
    
    print("="*60)
    print("ORI SIGNAL CHECKER")
    print("Origin of Replication Analysis Tool")
    print("="*60)
    print(f"\nInput file: {args.fasta_file}")
    
    # Check if file exists
    if not Path(args.fasta_file).exists():
        print(f"\nERROR: File '{args.fasta_file}' not found!")
        print("Please check the file path and try again.")
        return
    
    # Read sequence
    sequence = read_fasta(args.fasta_file)
    print(f"Sequence length: {len(sequence):,} bp")
    print(f"GC content: {((sequence.count('G') + sequence.count('C')) / len(sequence) * 100):.2f}%")
    
    # 1. K-mer enrichment analysis
    positions, top_kmers, enrichment_matrix, all_kmer_counts = kmer_enrichment_analysis(
        sequence, k=args.kmer_size, window_size=args.window_size, step=args.step
    )
    
    # 2. Clump finding
    clump_kmers, kmer_positions, clump_regions = find_clumps(
        sequence, L=args.clump_length, k=args.kmer_size, t=args.clump_threshold
    )
    
    # 3. GC skew calculation
    gc_positions, gc_skew_values, cumulative_skew, min_skew_positions = calculate_gc_skew(
        sequence, window_size=args.window_size, step=args.step
    )
    
    # 4. Find ORI candidates
    ori_candidates = find_ori_candidates(
        sequence, k=args.kmer_size, window_size=args.window_size, step=args.step,
        clump_kmers=clump_kmers, min_skew_positions=min_skew_positions
    )
    
    # 5. Generate plots
    plot_results(positions, enrichment_matrix, top_kmers, gc_positions, 
                 gc_skew_values, cumulative_skew, clump_regions, 
                 ori_candidates, output_prefix=args.output_prefix)
    
    # Save detailed results
    output_file = f'{args.output_prefix}_results.txt'
    with open(output_file, 'w') as f:
        f.write("="*60 + "\n")
        f.write("ORI SIGNAL CHECKER - DETAILED RESULTS\n")
        f.write("="*60 + "\n\n")
        
        f.write(f"Input file: {args.fasta_file}\n")
        f.write(f"Sequence length: {len(sequence):,} bp\n\n")
        
        f.write("Parameters:\n")
        f.write(f"  K-mer size: {args.kmer_size}\n")
        f.write(f"  Window size: {args.window_size}\n")
        f.write(f"  Step size: {args.step}\n")
        f.write(f"  Clump parameters: L={args.clump_length}, t={args.clump_threshold}\n\n")
        
        f.write("TOP ORI CANDIDATES:\n")
        f.write("-" * 60 + "\n")
        for i, candidate in enumerate(ori_candidates[:5], 1):
            f.write(f"\nCandidate {i}:\n")
            f.write(f"  Position: {candidate['position']:,}\n")
            f.write(f"  Region: {candidate['start']:,} - {candidate['end']:,}\n")
            f.write(f"  Clump k-mers in region: {candidate['clump_count']}\n")
            f.write(f"  Score: {candidate['score']:.2f}\n")
        
        f.write("\n" + "="*60 + "\n")
        f.write("CLUMP K-MERS (forming ({}, {}, {})-clumps):\n".format(
            args.clump_length, args.kmer_size, args.clump_threshold))
        f.write("-" * 60 + "\n")
        for kmer in sorted(clump_kmers):
            f.write(f"  {kmer}\n")
    
    print(f"\nSaved detailed results: {output_file}")
    
    print("\n" + "="*60)
    print("ANALYSIS COMPLETE!")
    print("="*60)


if __name__ == '__main__':
    main()

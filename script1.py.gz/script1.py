#!/usr/bin/env python3
"""
ORI Signal Checker: K-mer enrichment and plotting
Identifies overrepresented k-mers along a genome by counting their occurrences 
in sliding windows and visualizes enrichment patterns.
"""

import sys
from collections import defaultdict
import matplotlib.pyplot as plt
import numpy as np

def read_fasta(filename):
    """Read a FASTA file and return the sequence."""
    sequence = ""
    try:
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip()
                if not line.startswith('>'):
                    sequence += line.upper()
        return sequence
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        sys.exit(1)
    except Exception as e:
        print(f"Error reading file: {e}")
        sys.exit(1)

def count_kmers(sequence, k):
    """Count all k-mers in the sequence."""
    kmer_counts = defaultdict(int)
    for i in range(len(sequence) - k + 1):
        kmer = sequence[i:i+k]
        if 'N' not in kmer:  # Skip k-mers with ambiguous bases
            kmer_counts[kmer] += 1
    return kmer_counts

def get_top_kmers(kmer_counts, top_n=10):
    """Get the top N most frequent k-mers."""
    sorted_kmers = sorted(kmer_counts.items(), key=lambda x: x[1], reverse=True)
    return [kmer for kmer, count in sorted_kmers[:top_n]]

def sliding_window_kmer_count(sequence, kmer, window_size, step):
    """
    Count occurrences of a k-mer in sliding windows across the sequence.
    Returns window positions and counts.
    """
    positions = []
    counts = []
    k = len(kmer)
    
    for start in range(0, len(sequence) - window_size + 1, step):
        window = sequence[start:start + window_size]
        count = 0
        for i in range(len(window) - k + 1):
            if window[i:i+k] == kmer:
                count += 1
        positions.append(start + window_size // 2)  # Center of window
        counts.append(count)
    
    return positions, counts

def plot_enrichment(all_positions, all_counts, top_kmers, sequence_length):
    """Create a plot showing k-mer enrichment across the genome."""
    plt.figure(figsize=(14, 8))
    
    colors = plt.cm.tab10(np.linspace(0, 1, len(top_kmers)))
    
    max_count = 0
    peak_info = {}
    
    for idx, (kmer, positions, counts) in enumerate(zip(top_kmers, all_positions, all_counts)):
        plt.plot(positions, counts, label=kmer, color=colors[idx], linewidth=1.5, alpha=0.7)
        
        # Find peak for this k-mer
        if counts:
            max_val = max(counts)
            if max_val > max_count:
                max_count = max_val
            max_idx = counts.index(max_val)
            peak_position = positions[max_idx]
            peak_info[kmer] = (peak_position, max_val)
    
    plt.xlabel('Genomic Position (bp)', fontsize=12, fontweight='bold')
    plt.ylabel('K-mer Count per Window', fontsize=12, fontweight='bold')
    plt.title('K-mer Enrichment Analysis - ORI Signal Detection', fontsize=14, fontweight='bold')
    plt.legend(loc='upper right', fontsize=9, ncol=2)
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.xlim(0, sequence_length)
    
    # Add vertical line at overall peak
    if peak_info:
        overall_peak_kmer = max(peak_info.items(), key=lambda x: x[1][1])
        peak_pos = overall_peak_kmer[1][0]
        plt.axvline(x=peak_pos, color='red', linestyle='--', linewidth=2, alpha=0.5, 
                   label=f'Peak at {peak_pos:,} bp')
    
    plt.tight_layout()
    plt.savefig('image1.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    return peak_info

def main():
    # Parameters
    k = 8
    window_size = 5000
    step = 500
    
    # Check command line arguments
    if len(sys.argv) != 2:
        print("Usage: python script1.py genomic.fa")
        sys.exit(1)
    
    fasta_file = sys.argv[1]
    
    print(f"Reading sequence from {fasta_file}...")
    sequence = read_fasta(fasta_file)
    print(f"Sequence length: {len(sequence):,} bp")
    
    print(f"\nCounting {k}-mers...")
    kmer_counts = count_kmers(sequence, k)
    print(f"Total unique {k}-mers found: {len(kmer_counts):,}")
    
    print(f"\nIdentifying top overrepresented {k}-mers...")
    top_kmers = get_top_kmers(kmer_counts, top_n=10)
    
    print("\nTop 10 most frequent k-mers:")
    for i, kmer in enumerate(top_kmers, 1):
        print(f"  {i}. {kmer}: {kmer_counts[kmer]:,} occurrences")
    
    print(f"\nPerforming sliding window analysis...")
    print(f"  Window size: {window_size:,} bp")
    print(f"  Step size: {step} bp")
    
    all_positions = []
    all_counts = []
    
    for kmer in top_kmers:
        positions, counts = sliding_window_kmer_count(sequence, kmer, window_size, step)
        all_positions.append(positions)
        all_counts.append(counts)
    
    print("\nGenerating enrichment plot...")
    peak_info = plot_enrichment(all_positions, all_counts, top_kmers, len(sequence))
    
    print("\nPlot saved as: image1.png")
    
    # Print peak information
    print("\nPeak positions for each k-mer:")
    for kmer, (position, count) in sorted(peak_info.items(), key=lambda x: x[1][1], reverse=True):
        print(f"  {kmer}: Peak at position {position:,} bp (count: {count})")
    
    # Overall peak
    if peak_info:
        overall_peak = max(peak_info.items(), key=lambda x: x[1][1])
        print(f"\nOverall highest peak: K-mer '{overall_peak[0]}' at position {overall_peak[1][0]:,} bp with count {overall_peak[1][1]}")

if __name__ == "__main__":
    main()
